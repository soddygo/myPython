#coding:utf-8

CorpID='wx4cdefe5c35ade014'
Secret='W2O9-i2JEsOzUq2AlSDsgmNureHs06ZIFGhIj2wyaslUXCl3uM4NIC14b78NNZvh'

DEBUG=0

ToUser='@all'
AgentId=2